class SubmoduleClass:
    id=''
    method_id=''
    task=''
    forBuilding=0
    inputs=[]
    outputs=[]

    def __init__(self,id,task):
        self.task=task
        self.forBuilding=0

    def __init__(self,id,task,method_id,forBuilding):
        self.id = id
        self.task=task
        self.method_id = method_id
        self.forBuilding=forBuilding
    def addInput(self,input):
        self.inputs.append(input)

    def addOutput(self,output):
        self.outputs.append(output)

    def getSubmoduleID(self):
        return self.id
    def getSubmoduleTask(self):
        return self.task
    def getMethodID(self):
        return self.method_id
    def getMethodType(self):
        if self.forBuilding==1:
            return 'build-model'
        else:
            return 'predict'

    def getSubmoduleOutputs(self):
        return self.outputs
    def getSubmoduleInputs(self):
        return self.inputs