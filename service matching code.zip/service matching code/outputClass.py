class OutputClass:
    name = ''
    format = ''


    def __init__(self, name, format):
        self.name = name
        self.format = format


    def getOutputName(self):
        return self.name

    def getOutputFormat(self):
        return self.format
