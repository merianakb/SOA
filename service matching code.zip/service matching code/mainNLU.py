from MethodIdentification import methodsIdentification
from RestAPIIdentification import restapiIdentification
from NLU import nlu

methods_Identification= methodsIdentification()
restapi_Identification=restapiIdentification()
nlu_component=nlu('52VTO3XKR2NNRKWQLUUZTPBANV5N6KUE')
predictive_methods=[]
building_methods=[]
submodules=[]


# Press the green button in the gutter to run the script.
#if __name__ == '__main__':
def getMethodFromNL(NLQuery):
    global predictive_methods,building_methods,submodules
    res=nlu_component.receiveNLQuery(NLQuery)
    if res[0]==0:
        return res
    else:
        method_properties=res[1]
    if 'predictionType' in method_properties.keys():
        prediction_type=method_properties['predictionType']
    else:
        prediction_type=''
    if 'Awareness' in method_properties.keys():
        if method_properties['Awareness']=='PA':
            pa='yes'
        else:
            pa='no'
    else:
        pa=''
    if 'type' in method_properties.keys():
        type=method_properties['type']
    else:
        type=''
    if 'Methodology' in method_properties.keys():
        methodology=method_properties['Methodology']
    else:
        methodology=''
    if 'algorithm' in method_properties.keys():
        algo=method_properties['algorithm']
    else:
        algo=[]

    response=methods_Identification.getMethodsThatFeetReq(prediction_type,pa,type,methodology,algo)
    if not response[0]==0:
        predictive_methods=response[2]
        building_methods=response[3]
        submodules=response[4]
    return response[0],response[1]
def getLiteralInputsValues(literal_inputs):
    values=[]
    if len(literal_inputs)==0:
        return []
    print('Please provide the following input values: ')
    for inp in literal_inputs:
        input_value={}
        input_value['name'] = inp['name']
        value=input(inp['name']+' in '+inp['format']+' format: ')
        input_value['value']=value
        values.append(input_value)
    return values

def getResourceInputsValues(resource_inputs):
    values=[]
    if len(resource_inputs)==0:
        return []
    print('Please provide the identifier of the following resource inputs: ')
    for inp in resource_inputs:
        input_value={}
        input_value['name']=inp['name']
        value=input(inp['name']+': ')
        input_value['value']=value
        values.append(input_value)
    return values
def getRestAPIOutput(predictive_methods,building_methods,submodules,select_id):
    restapi_url=''
    output=''
    returned_url=0
    resource_inputs_values=[]
    selected_method_prediction=methods_Identification.isMethodExist(predictive_methods,select_id)
    if selected_method_prediction[0]==1:
        print('It is a prediction method')
        output=output+'It is a prediction method'+'\n'
        literal_inputs = methods_Identification.getMethodLiteralInputs(predictive_methods,select_id)
        resource_inputs = methods_Identification.getMethodResourceInputs(predictive_methods, select_id)
        print("Literal inputs: ")
        print(literal_inputs)
        print("Resource inputs: ")
        print(resource_inputs)
        literal_inputs_values=getLiteralInputsValues(literal_inputs)
        resource_inputs_values = getResourceInputsValues(resource_inputs)
        restapi_url = restapi_Identification.identifyRestAPI('predict', selected_method_prediction[1],literal_inputs_values,resource_inputs_values,0,'')
        print(restapi_url)
        returned_url=1
        output = output + restapi_url + '\n'
    else:
        selected_method_building=methods_Identification.isMethodExist(building_methods,select_id)
        if selected_method_building[0]==1:
            print('It is a building model method')
            output = output + 'It is a building model method' + '\n'
            literal_inputs=methods_Identification.getMethodLiteralInputs(building_methods,select_id)
            resource_inputs = methods_Identification.getMethodResourceInputs(building_methods, select_id)
            print("Literal inputs: ")
            print(literal_inputs)
            print("Resource inputs: ")
            print(resource_inputs)
            literal_inputs_values = getLiteralInputsValues(literal_inputs)
            resource_inputs_values = getResourceInputsValues(resource_inputs)
            restapi_url=restapi_Identification.identifyRestAPI('build-model',selected_method_building[1],literal_inputs_values,resource_inputs_values,0,'')
            print(restapi_url)
            returned_url=1
            output = output + restapi_url + '\n'
        else:
            selected_submodule=methods_Identification.isSubModuleExist(submodules,select_id)
            if selected_submodule[0]==1:
                print('It is a submodule')
                output = output + 'It is a submodule'+ '\n'
                task,method_id,method_type,literal_inputs,resource_inputs = methods_Identification.getSubmoduleInfos(submodules, select_id)
                print("Literal inputs: ")
                print(literal_inputs)
                print("Resource inputs: ")
                print(resource_inputs)
                literal_inputs_values = getLiteralInputsValues(literal_inputs)
                resource_inputs_values = getResourceInputsValues(resource_inputs)
                if method_type=='build-model':
                    building_method=methods_Identification.isMethodExist(building_methods,method_id)
                    if building_method[0]==1:
                        restapi_url = restapi_Identification.identifyRestAPI('build-model', building_method[1],literal_inputs_values,resource_inputs_values,1,task)
                        print(restapi_url)
                        returned_url = 1
                        output = output + restapi_url + '\n'
                    else:
                        print('Error, building method does not exist')
                        returned_url = 0
                        output = output + 'Error, building method does not exist' + '\n'
                else:
                    prediction_method = methods_Identification.isMethodExist(predictive_methods, method_id)
                    if prediction_method[0]==1:
                        restapi_url = restapi_Identification.identifyRestAPI('predict', prediction_method[1],
                                                                      literal_inputs_values,resource_inputs_values, 1, task)
                        print(restapi_url)
                        returned_url = 1
                        output = output + restapi_url + '\n'
                    else:
                        print('Error, prediction method does not exist')
                        returned_url = 0
                        output = output + 'Error, prediction method does not exist' + '\n'

            else:
                print('ID does not exist')
                returned_url = 0
                output = output + 'ID does not exist' + '\n'
    return output,returned_url,restapi_url,resource_inputs_values


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
