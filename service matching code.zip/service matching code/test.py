from collections import defaultdict

from inputClass import InputClass

def inPredicitiveMethod(self, predictive_methods,method_id):
    for method in predictive_methods:
        if method.getMethodID()==method_id:
            return 1
    return 0
def getPredictiveMethodsDict(self, data):
    predictive_methods = []
    buildingModel_methods=[]
    submodules=[]
    for record in data:
        output = record[0]
        method = record[1]
        method_id = str(record[2])
        input = record[3]
        method_submodule=None
        submodule_id=None
        submodule_input=None
        submodule_output=None
        if record[4] is not None:
            method_submodule = record[4]
            submodule_id=record[5]
        if record[6] is not None:
            submodule_output=record[6]
        if record[7] is not None:
            submodule_input=record[7]
        building_method = None
        building_id = None
        building_input = None
        building_output = None
        if record[8] is not None:
            building_method = record[8]
            building_id=record[9]
            building_output=record[10]
            building_input=record[11]
        building_method_submodule = None
        building_submodule_id = None
        building_submodule_input = None
        building_submodule_output = None
        if record[12] is not None:
            building_method_submodule = record[12]
            building_submodule_id=record[13]
        if record[14] is not None:
            building_submodule_output=record[14]
        if record[15] is not None:
            building_submodule_input=record[15]


        prediction_type = method['predictionType']
        method_pa = method['processAware']
        method_type = method['type']
        method_methodology = method['methodology']
        method_algo = method['algo']
        method_predictorModel = method['predictorModel']
        method_producedModel = method['producedModel']
        output_name = output['name']
        output_format = output['format']
        input_name = input['name']
        input_format = input['format']
        input_type = input['type']
        input_required = input['required']
        if this.inPredicitiveMethod(predictive_methods,method_id):
            predictive_methods[prediction_type] = []
        # check whether the method already exist
        method_exist = self.isMethodExist(predictive_methods, prediction_type, method_id)
        # the method already exist
        if method_exist[0] == 1:
            # check the input
            if not input_name == '':
                if self.isMethodInputExist(predictive_methods, prediction_type, method_id, input_name) == 0:
                    new_input = InputClass(input_name, input_format, input_type, input_required)
                    method_exist[1].addInput(new_input)
        # the method does not exist:
        else:
            new_method = MethodClass(method_id, method_pa, method_type, method_methodology, method_algo,
                                     method_predictorModel, method_producedModel)
            if not input_name == '':
                new_input = InputClass(input_name, input_format, input_type, input_required)
                new_method.addInput(new_input)
            # add method to the dictionary
            predictive_methods[prediction_type].append(new_method)
    return predictive_methods


def getPredictiveMethodsDict(self,data):
        predictive_methods = defaultdict(dict)
        for record in data:
            output=record[0]
            method=record[1]
            method_id=str(record[2])
            input=record[3]
            method_submodule=None
            building_method=None
            building_method_submodule=None
            if record[4] is not None:
                method_submodule=record[4]
            if record[5] is not None:
                building_method=record[5]
            if record[6] is not None:
                building_method_submodule=record[6]

            prediction_type=method['predictionType']
            method_pa=method['processAware']
            method_type=method['type']
            method_methodology=method['methodology']
            method_algo=method['algo']
            method_predictorModel=method['predictorModel']
            method_producedModel=method['producedModel']
            output_name=output['name']
            output_format=output['format']
            input_name=input['name']
            input_format=input['format']
            input_type=input['type']
            input_required = input['required']
            if not prediction_type in predictive_methods.keys():
                predictive_methods[prediction_type]=[]
            # check whether the method already exist
            method_exist=self.isMethodExist(predictive_methods,prediction_type,method_id)
            #the method already exist
            if method_exist[0]==1:
                #check the input
                if not input_name=='':
                    if self.isMethodInputExist(predictive_methods,prediction_type,method_id,input_name)==0:
                        new_input=InputClass(input_name,input_format,input_type,input_required)
                        method_exist[1].addInput(new_input)
            #the method does not exist:
            else:
                new_method=MethodClass(method_id,method_pa,method_type,method_methodology,method_algo,method_predictorModel,method_producedModel)
                if not input_name=='':
                    new_input=InputClass(input_name,input_format,input_type,input_required)
                    new_method.addInput(new_input)
                #add method to the dictionary
                predictive_methods[prediction_type].append(new_method)
        return predictive_methods