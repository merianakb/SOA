from collections import defaultdict

from authenticationParameters import authenticationParameters
from py2neo import Graph
#import Dictionary
from inputClass import InputClass
from methodClass import MethodClass
from outputClass import OutputClass
from submoduleClass import SubmoduleClass

authP= authenticationParameters()

class methodsIdentification:

    def printDictionary(self,predictive_methods, building_methods, submodules):
            output=''
            print()
            printed_building_methods_ids=[]
            print('Methods: ')
            output=output+'Methods:\n '
            for method in predictive_methods:
                print('method_id: '+method.getMethodID())
                output = output + 'method_id: '+method.getMethodID()+'\n'
                print('prediction_type: ' + method.getMethodPredictionType())
                output=output+'prediction_type: ' + method.getMethodPredictionType()+'\n'
                print('method_awareness: ' + method.getMethodAwareness())
                output = output + 'method_awareness: ' + method.getMethodAwareness()+'\n'
                print('method_type: ' + method.getMethodType())
                output = output + 'method_type: ' + method.getMethodType()+'\n'
                print('method_methodology: ' + method.getMethodMethodology())
                output = output + 'method_methodology: ' + method.getMethodMethodology()+'\n'
                print('method_algo: ' + str(method.getMethodAlgo()))
                output = output + 'method_algo: ' + str(method.getMethodAlgo())+'\n'
                print('method_task: ' + method.getMethodTask())
                output = output + 'method_task: ' + method.getMethodTask()+'\n'
                inputs=method.getMethodInputs()
                print('inputs:')
                output=output+'inputs: '+'\n'
                for input in inputs:
                    print('\tinput_name: '+input.getInputName())
                    output=output+'\tinput_format: '+input.getInputFormat()+'\n'
                    print('\tinput_format: '+input.getInputFormat())
                    output = output + '\tinput_format: '+input.getInputFormat()+'\n'
                    print('\tinput_type: ' + input.getInputType())
                    output = output + '\tinput_type: ' + input.getInputType()+'\n'
                    print()
                    output=output+'\n'
                outputs=method.getMethodOutputs()
                print('output:')
                output=output+'output: '+'\n'
                for out in outputs:
                    print('\toutput_name: ' + out.getOutputName())
                    output = output + '\toutput_name: ' + out.getOutputName()+'\n'
                    print('\toutput_format: ' + out.getOutputFormat())
                    output = output + '\toutput_format: ' + out.getOutputFormat()+'\n'
                    print()
                    output = output + '\n'
                print('-----------------------------------')
                output = output + '-----------------------------------'+'\n'
                method_submodules=method.getMethodSubmodules()
                print('submodules:')
                output = output + 'submodules:'+'\n'
                for submodule_id in method_submodules:
                    method_submodule = self.getSubmodule(submodules, submodule_id)
                    if method_submodule is not None:
                        print('\tsubmodule_id: ' + method_submodule.getSubmoduleID())
                        output = output + '\tsubmodule_id: ' + method_submodule.getSubmoduleID()+'\n'
                        print('\ttask: ' + method_submodule.getSubmoduleTask())
                        output = output + '\ttask: ' + method_submodule.getSubmoduleTask()+'\n'
                        print()
                        output = output + '\n'
                print('-----------------------------------')
                output = output + '-----------------------------------'+'\n'

                print('building model:')
                output = output + 'building model'+'\n'
                building_method_ids = method.getBuildingMethods()
                for building_method_id in building_method_ids:
                    printed_building_methods_ids.append(building_method_id)
                    print('\tmethod_id: '+building_method_id)
                    output = output + '\tmethod_id: '+building_method_id+'\n'
                    building_method = self.getBuildingMethod(building_methods, building_method_id)
                    if building_method is not None:
                        building_inputs = building_method.getMethodInputs()
                        print('\tinputs:')
                        output = output + '\tinputs:'+'\n'
                        for input in building_inputs:
                            print('\t\tinput_name: ' + input.getInputName())
                            output = output + '\t\tinput_name: ' + input.getInputName()+'\n'
                            print('\t\tinput_format: ' + input.getInputFormat())
                            output = output + '\t\tinput_format: ' + input.getInputFormat()+'\n'
                            print('\t\tinput_type: ' + input.getInputType())
                            output = output + '\t\tinput_type: ' + input.getInputType()+'\n'
                            print()
                            output = output + '\n'
                        building_outputs = building_method.getMethodOutputs()
                        print('\toutput:')
                        output = output + '\toutputs:'+'\n'
                        for out in building_outputs:
                            print('\t\toutput_name: ' + out.getOutputName())
                            output = output + '\t\toutput_name: ' + out.getOutputName()+'\n'
                            print('\t\toutput_format: ' + out.getOutputFormat())
                            output = output + '\t\toutput_format: ' + out.getOutputFormat()+'\n'
                            print()
                            output = output + '\n'
                        building_submodules = building_method.getMethodSubmodules()
                        print('\tsubmodules:')
                        output = output + '\tsubmodules:'+'\n'
                        for submodule_id in building_submodules:
                            building_submodule=self.getSubmodule(submodules,submodule_id)
                            if building_submodule is not None:
                                print('\t\tsubmodule_id: ' + building_submodule.getSubmoduleID())
                                output = output + '\t\tsubmodule_id: ' + building_submodule.getSubmoduleID()+'\n'
                                print('\t\ttask: ' + building_submodule.getSubmoduleTask())
                                output = output + '\t\ttask: ' + building_submodule.getSubmoduleTask()+'\n'
                                print()
                                output = output + '\n'
                        print('-----------------------------------')
                        output = output + '-----------------------------------'+'\n'
                print()
                output = output + '\n'
                print('**********************************************************************')
                output = output + '**********************************************************************'+'\n'
            #print remaining building methods
            for method in building_methods:
                if not method.getMethodID() in printed_building_methods_ids:
                    print('method_id: ' + method.getMethodID())
                    output = output + 'method_id: ' + method.getMethodID()+'\n'
                    print('prediction_type: ' + method.getMethodPredictionType())
                    output = output + 'prediction_type: ' + method.getMethodPredictionType()+'\n'
                    print('method_awareness: ' + method.getMethodAwareness())
                    output = output + 'method_awareness: ' + method.getMethodAwareness()+'\n'
                    print('method_type: ' + method.getMethodType())
                    output = output + 'method_type: ' + method.getMethodType()+'\n'
                    print('method_methodology: ' + method.getMethodMethodology())
                    output = output + 'method_methodology: ' + method.getMethodMethodology()+'\n'
                    print('method_algo: ' + str(method.getMethodAlgo()))
                    output = output + 'method_algo: ' + str(method.getMethodAlgo())+'\n'
                    print('method_task: ' + method.getMethodTask())
                    output = output + 'method_task: ' + method.getMethodTask()+'\n'
                    inputs = method.getMethodInputs()
                    print('inputs:')
                    output = output + 'inputs:'+'\n'
                    for input in inputs:
                        print('\tinput_name: ' + input.getInputName())
                        output = output + '\tinput_name: ' + input.getInputName()+'\n'
                        print('\tinput_format: ' + input.getInputFormat())
                        output = output + '\tinput_format: ' + input.getInputFormat()+'\n'
                        print('\tinput_type: ' + input.getInputType())
                        output = output + '\tinput_type: ' + input.getInputType()+'\n'
                        print()
                        output = output + '\n'
                    outputs = method.getMethodOutputs()
                    print('output:')
                    output = output + 'output:'+'\n'
                    for out in outputs:
                        print('\toutput_name: ' + out.getOutputName())
                        output = output + '\toutput_name: ' + out.getOutputName()+'\n'
                        print('\toutput_format: ' + out.getOutputFormat())
                        output = output + '\toutput_format: ' + out.getOutputFormat()+'\n'
                        print()
                        output = output + '\n'
                    print('-----------------------------------')
                    output = output + '-----------------------------------'+'\n'
                    method_submodules = method.getMethodSubmodules()
                    print('submodules:')
                    output = output + 'submodules:'+'\n'
                    for submodule_id in method_submodules:
                        method_submodule = self.getSubmodule(submodules, submodule_id)
                        if method_submodule is not None:
                            print('\tsubmodule_id: ' + method_submodule.getSubmoduleID())
                            output = output + '\tsubmodule_id: ' + method_submodule.getSubmoduleID()+'\n'
                            print('\ttask: ' + method_submodule.getSubmoduleTask())
                            output = output + '\ttask: ' + method_submodule.getSubmoduleTask()+'\n'
                            print()
                            output = output + '\n'
                    print('-----------------------------------')
                    output = output + '-----------------------------------'+'\n'
            return output



    def inPredicitiveMethod(self, predictive_methods, method_id):
        for method in predictive_methods:
            if method.getMethodID() == method_id:
                return 1
        return 0
    def getPredictiveMethodsDict(self,data):
        predictive_methods = []
        buildingModel_methods = []
        submodules = []
        for record in data:
            output = record[0]
            method = record[1]
            method_id = str(record[2])
            input = record[3]

            prediction_type = method['predictionType']
            method_pa = method['processAware']
            method_type = method['type']
            method_methodology = method['methodology']
            method_algo = method['algo']
            method_predictorModel = method['model']
            method_producedModel = method['producedModel']
            method_task=method['task']
            output_name = output['name']
            output_format = output['format']
            input_name = input['name']
            input_format = input['format']
            input_type = input['type']
            input_required = input['required']
            # check whether the method already exist
            if method_task=='build-model':
                method_exist = self.isMethodExist(buildingModel_methods, method_id)
            else:
                method_exist = self.isMethodExist(predictive_methods, method_id)
            # the method already exist
            if method_exist[0] == 1:
                new_method=method_exist[1]
            else:
                new_method = MethodClass(method_id, prediction_type, method_pa, method_type, method_methodology, method_algo,
                                         method_predictorModel, method_producedModel,method_task)
            # check the input
            if not input_name == '':
                if method_task=='build-model':
                    input_exist=self.isMethodInputExist(buildingModel_methods, method_id, input_name)
                else:
                    input_exist = self.isMethodInputExist(predictive_methods, method_id, input_name)
                if input_exist == 0:
                    new_input = InputClass(input_name, input_format, input_type)
                    new_method.addInput(new_input)
            # check the output
            if not output_name == '':
                if method_task=='build-model':
                    output_exist=self.isMethodOutputExist(buildingModel_methods, method_id, output_name)
                else:
                    output_exist = self.isMethodOutputExist(predictive_methods, method_id, output_name)
                if output_exist == 0:
                    new_output = OutputClass(output_name, output_format)
                    new_method.addOutput(new_output)
            # check submodules
            if record[4] is not None:
                method_submodule_task = record[4]['task']
                submodule_id = str(record[5])
                # check whether the submodule already exist
                submodule_exist=self.isSubModuleExist(submodules,submodule_id)
                if submodule_exist[0]==1:
                    new_submodule=submodule_exist[1]
                else:
                    if method_task=='build-model':
                        new_submodule= SubmoduleClass(submodule_id,method_submodule_task,method_id,0)
                    else:
                        new_submodule = SubmoduleClass(submodule_id, method_submodule_task, method_id, 1)
                # check submodule output
                if record[6] is not None:
                    submodule_output = record[6]
                    submodule_output_name=submodule_output['name']
                    submodule_output_format=submodule_output['format']
                    output_exist=self.isSubmoduleOutputExist(submodules,submodule_id,submodule_output_name)
                    if output_exist==0:
                        new_output=OutputClass(submodule_output_name, submodule_output_format)
                        new_submodule.addOutput(new_output)
                # check submodule input
                if record[7] is not None:
                    submodule_input = record[7]
                    submodule_input_name=submodule_input['name']
                    submodule_input_format = submodule_input['format']
                    submodule_input_type = submodule_input['type']
                    input_exist = self.isSubmoduleInputExist(submodules, submodule_id, submodule_input_name)
                    if input_exist == 0:
                        new_input = InputClass(submodule_input_name, submodule_input_format, submodule_input_type)
                        new_submodule.addInput(new_input)
                #add submodule to the array
                if submodule_exist[0]==0:
                    submodules.append(new_submodule)
                # add submodule id to the method
                if method_task == 'build-model':
                    sb_exist = self.isMethodSubmoduleExist(buildingModel_methods, method_id, submodule_id)
                else:
                    sb_exist = self.isMethodSubmoduleExist(predictive_methods, method_id, submodule_id)
                if sb_exist==0:
                    new_method.addSubmodule(submodule_id)

            # check building_model method
            if method_task=='predict':
                if record[8] is not None:
                    building_method_task = record[8]['task']
                    building_id = str(record[9])
                    # check whether the method already exist
                    building_method_exist = self.isMethodExist(buildingModel_methods, building_id)
                    # the method already exist
                    if building_method_exist[0] == 1:
                        new_building_method = building_method_exist[1]
                    else:
                        #building model and prediction method have the same characteristics
                        new_building_method = MethodClass(building_id, prediction_type, method_pa, method_type, method_methodology, method_algo,
                                             method_predictorModel, method_producedModel, building_method_task)
                    building_method_output = record[10]
                    building_method_input = record[11]
                    # check building model input
                    if building_method_input is not None:
                        building_method_input_name = building_method_input['name']
                        building_method_input_format = building_method_input['format']
                        building_method_input_type = building_method_input['type']
                        if self.isMethodInputExist(buildingModel_methods, building_id, building_method_input_name) == 0:
                            new_input = InputClass(building_method_input_name, building_method_input_format,
                                               building_method_input_type)
                            new_building_method.addInput(new_input)
                    # check building model output
                    if building_method_output is not None:
                        building_method_output_name = building_method_output['name']
                        building_method_output_format = building_method_output['format']
                        building_method_output_exist = self.isMethodOutputExist(buildingModel_methods, building_id, building_method_output_name)
                        if building_method_output_exist == 0:
                            new_output = OutputClass(building_method_output_name, building_method_output_format)
                            new_building_method.addOutput(new_output)
                    # check building model submodules
                    if record[12] is not None:
                        building_submodule = record[12]
                        building_submodule_task = building_submodule['task']
                        building_submodule_id = str(record[13])
                        # check whether the submodule already exist
                        submodule_exist = self.isSubModuleExist(submodules, building_submodule_id)
                        if submodule_exist[0] == 1:
                            new_submodule = submodule_exist[1]
                        else:
                            new_submodule = SubmoduleClass(building_submodule_id, building_submodule_task, building_id, 1)
                        # check building submodule output
                        if record[14] is not None:
                            building_submodule_output = record[14]
                            building_submodule_output_name = building_submodule_output['name']
                            building_submodule_output_format = building_submodule_output['format']
                            output_exist = self.isSubmoduleOutputExist(submodules, building_submodule_id,building_submodule_output_name)
                            if output_exist == 0:
                                new_output = OutputClass(building_submodule_output_name, building_submodule_output_format)
                                new_submodule.addOutput(new_output)
                        # check submodule input
                        if record[15] is not None:
                            building_submodule_input = record[15]
                            building_submodule_input_name = building_submodule_input['name']
                            building_submodule_input_format = building_submodule_input['format']
                            building_submodule_input_type = building_submodule_input['type']
                            input_exist = self.isSubmoduleInputExist(submodules, building_submodule_id,
                                                                          building_submodule_input_name)
                            if input_exist == 0:
                                new_input = InputClass(building_submodule_input_name, building_submodule_input_format,
                                                           building_submodule_input_type)
                                new_submodule.addInput(new_input)
                        # add submodule to the array
                        if submodule_exist[0] == 0:
                            submodules.append(new_submodule)
                        # add submodule id to the building method
                        if self.isMethodSubmoduleExist(buildingModel_methods, building_id, building_submodule_id) == 0:
                            new_building_method.addSubmodule(building_submodule_id)
                    # add building method to the array
                    if building_method_exist[0] == 0:
                        buildingModel_methods.append(new_building_method)
                    # add building model method id to the method
                    if self.isMethodBuildingModelExist(predictive_methods, method_id, building_id) == 0:
                        new_method.addBuildingMethod(building_id)
            # add method to the array
            if method_task=='predict' and self.isMethodExist(predictive_methods,method_id)[0] == 0:
                predictive_methods.append(new_method)
            if method_task=='build' and self.isMethodExist(buildingModel_methods,method_id)[0] == 0:
                buildingModel_methods.append(new_method)

        return predictive_methods,buildingModel_methods,submodules

    def isMethodExist(self, methods, method_id):
        for method in methods:
            if method.getMethodID()==method_id:
                return 1,method
        return 0,None
    def isSubModuleExist(self,submodules, submodule_id):
        for submodule in submodules:
            if submodule.getSubmoduleID()==submodule_id:
                return 1,submodule
        return 0,None

    def isMethodInputExist(self,methods, method_id, input_name):
        for method in methods:
            if method.getMethodID() == method_id:
                inputs=method.getMethodInputs()
                for input in inputs:
                    if input.getInputName()==input_name:
                        return 1
        return 0
    def isMethodOutputExist(self,methods, method_id, output_name):
        for method in methods:
            if method.getMethodID() == method_id:
                outputs=method.getMethodOutputs()
                for output in outputs:
                    if output.getOutputName()==output_name:
                        return 1
        return 0
    def isMethodSubmoduleExist(self,methods,method_id,submodule_id):
        for method in methods:
            if method.getMethodID() == method_id:
                subm=method.getMethodSubmodules()
                for submID in subm:
                    if submID==submodule_id:
                        return 1
        return 0
    def isMethodBuildingModelExist(self,predictive_methods,method_id,building_id):
        for method in predictive_methods:
            if method.getMethodID() == method_id:
                building=method.getBuildingMethods()
                for build in building:
                    if building_id==build:
                        return 1
        return 0
    def isSubmoduleOutputExist(self,submodules,submodule_id,output_name):
        for submodule in submodules:
            if submodule.getSubmoduleID() == submodule_id:
                outputs=submodule.getSubmoduleOutputs()
                for output in outputs:
                    if output.getOutputName()==output_name:
                        return 1
        return 0
    def isSubmoduleInputExist(self,submodules,submodule_id,input_name):
        for submodule in submodules:
            if submodule.getSubmoduleID() == submodule_id:
                inputs=submodule.getSubmoduleInputs()
                for input in inputs:
                    if input.getInputName()==input_name:
                        return 1
        return 0
    def getBuildingMethod(self,building_methods, id):
        for method in building_methods:
            if method.getMethodID()==id:
                return method
        return None
    def getSubmodule(self,submodules, id):
        for submodule in submodules:
            if submodule.getSubmoduleID()==id:
                return submodule
        return None
    def getMethodLiteralInputs(self,methods, method_id):
        literal_input = []
        for method in methods:
            if method.getMethodID() == method_id:
                inputs=method.getMethodInputs()
                for input in inputs:
                    if input.getInputType()=='literal':
                        inp={}
                        inp['name']=input.getInputName()
                        inp['format']=input.getInputFormat()
                        literal_input.append(inp)
        return literal_input
    def getMethodResourceInputs(self,methods, method_id):
        resource_input = []
        for method in methods:
            if method.getMethodID() == method_id:
                inputs=method.getMethodInputs()
                for input in inputs:
                    if input.getInputType()=='resource':
                        inp={}
                        inp['name']=input.getInputName()
                        inp['format']=input.getInputFormat()
                        resource_input.append(inp)
        return resource_input

    def getSubmoduleInfos(self,submodules, submodule_id):
        for submodule in submodules:
            if submodule.getSubmoduleID() == submodule_id:
                method_type=submodule.getMethodType()
                method_id=submodule.getMethodID()
                task=submodule.getSubmoduleTask()
                inputs=submodule.getSubmoduleInputs()
                literal_input=[]
                resource_input=[]
                for input in inputs:
                    if input.getInputType()=='literal':
                        inp={}
                        inp['name']=input.getInputName()
                        inp['format']=input.getInputFormat()
                        literal_input.append(inp)
                    if input.getInputType()=='resource':
                        inp={}
                        inp['name']=input.getInputName()
                        inp['format']=input.getInputFormat()
                        resource_input.append(inp)
        return task,method_id,method_type,literal_input,resource_input


    def execute_query(self,query):
        print(query)
        graph = Graph('bolt://localhost:7687',
                      auth=(authP.getAuthenticationUsername(), authP.getAuthenticationPassword()))
        try:
            data = graph.run(query).to_table()
        except:
            return 0,"Error, incorrect query"
        return 1,data

    def constructCypherQuery(self, output_preditionType, method_pa, method_type, method_methodology, method_algo):
        query=''
        match_clause="MATCH (om1:Output)-[:hasOutput]-(m1:Method)-[:hasInput]-(im1:Input)"
        optional_match1="OPTIONAL MATCH (m1)-[:submodule]-(mo1:Module)"
        optional_match2 = "OPTIONAL MATCH (omo1:Output)-[:hasOutput]-(mo1)-[:hasInput]-(imo1:Input)"
        optional_match3 = "OPTIONAL MATCH (m1)-[:buildingModel]->(m2:Method)"
        optional_match4="OPTIONAL MATCH (om2:Output)-[:hasOutput]-(m2)-[:hasInput]-(im2:Input)"
        optional_match5 = "OPTIONAL MATCH (m2)-[:submodule]-(mo2:Module) "
        optional_match6 = "OPTIONAL MATCH (omo2:Output)-[:hasOutput]-(mo2)-[:hasInput]-(imo2:Input)"
        where_clause="WHERE "
        is_where=0
        if not output_preditionType=='':
            where_clause=where_clause+" m1.predictionType=~ '(?i)"+output_preditionType+"' "
            is_where=1
        if not method_pa=='':
            if is_where==1:
                where_clause=where_clause+"AND "
            else:
                is_where=1
            where_clause=where_clause+"m1.processAware=~ '(?i)"+method_pa+"' "
        if not method_type=='':
            if is_where==1:
                where_clause=where_clause+"AND "
            else:
                is_where=1
            where_clause=where_clause+"m1.type=~ '(?i)"+method_type+"' "
        if not method_methodology=='':
            if is_where==1:
                where_clause=where_clause+"AND "
            else:
                is_where=1
            where_clause=where_clause+"m1.methodology=~ '(?i)"+method_methodology+"' "
        if not len(method_algo)==0:
            if is_where==1:
                where_clause=where_clause+"AND "
            else:
                is_where=1
            where_clause=where_clause+"m1.algo="+str(method_algo)+" "
        if is_where==0:
            return 0,"Incomplete query, you should specify at least one method property"
        return_clause="RETURN (om1),(m1),ID(m1),(im1),(mo1),ID(mo1),(omo1),(imo1),(m2),ID(m2),(om2),(im2),(mo2)," \
                      "ID(mo2),(omo2),(imo2)"
        query = match_clause + "\n" +where_clause + "\n"+ optional_match1 + "\n" + optional_match2 + "\n" + optional_match3 + "\n"\
                +optional_match4 + "\n"+optional_match5 + "\n"+optional_match6 + "\n" + return_clause
        return 1, query

    def getMethodsThatFeetReq(self, output_preditionType, method_pa, method_type, method_methodology, method_algo):
        response=self.constructCypherQuery(output_preditionType, method_pa, method_type, method_methodology, method_algo)
        #error on constructed query: no where clause
        if response[0]==0:
            print(response[1])
            return response[0],response[1],0,0,0
        # execute cypher query
        data_response=self.execute_query(response[1])
        #error while executing the query
        if data_response[0]==0:
            print(data_response[1])
            return data_response[0],data_response[1],0,0,0
        # print the queried methods
        predictive_methods,building_methods,submodules= self.getPredictiveMethodsDict(data_response[1])
        output=self.printDictionary(predictive_methods,building_methods,submodules)
        return 1,output,predictive_methods,building_methods,submodules

