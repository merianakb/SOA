from wit import Wit

class nlu:
    access_token=''
    client=''
    def __init__(self, access_token):
        self.access_token= access_token
        self.client = Wit(access_token=access_token)

    def receiveNLQuery(self,query):
        resp = self.client.message(query)
        print("entities detected:")
        for item in resp['entities']:
            str_item = str(item)
            str_item = str_item.split(":")[0]
            print(str_item)
        return self.getExtractedProperties(resp['entities'])

    def getExtractedProperties(self,entities):
        method_properties={}
        method_properties['algorithm']=[]
        for item in entities:
            str_item_role=str(item)
            str_item=str_item_role.split(":")[0]
            method,propertyName,propertyValue=str_item.split('_')
            propertyValue=propertyValue.replace('-',' ')
            if propertyName=='algorithm':
                method_properties['algorithm']= method_properties['algorithm'].append(propertyValue)
            else:
                method_properties[propertyName]=propertyValue
        if len(method_properties.keys())==0:
            return 0,'You should specify at least one of the methods properties'
        return 1,method_properties


