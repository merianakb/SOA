username='neo4j'
password='MyGraphP@ss'

class authenticationParameters:
    def getAuthenticationUsername(self):
        return username
    def getAuthenticationPassword(self):
        return password