from tkinter import *

from mainNLU import getMethodFromNL
from mainNLU import getRestAPIOutput

ID_selection=0
def send():
    msg = EntryBox.get("1.0", 'end-1c').strip()
    if msg.isdigit():
        sendID()
    else:
        sendMessage()

def sendMessage():
    msg = EntryBox.get("1.0",'end-1c').strip()
    EntryBox.delete("0.0",END)

    if msg != '':
        ChatLog.config(state=NORMAL)
        ChatLog.config(foreground="#442265", font=("Verdana", 12 ))
        ChatLog.insert(END, "You: " + msg + '\n\n')
        print(msg)
        res = getMethodFromNL(msg)
        output=res[1]

        #ChatLog.config(foreground="#000000", font=("Verdana", 12 ))
        ChatLog.tag_config('bg_yellow', background='yellow')
        ChatLog.insert(END, "Response: \n",'bg_yellow')
        ChatLog.insert(END, output)
        ChatLog.insert(END,'\n\n')
        if res[0]==1:
            ChatLog.tag_config('bg_yellow', background='yellow')
            ChatLog.insert(END, "Select method ID: \n", 'bg_yellow')
            ID_selection=1
        #ChatLog.config(state=DISABLED)
        #ChatLog.yview(END)
        #msg=''

def sendID():
    select_id = EntryBox.get("1.0", 'end-1c').strip()
    EntryBox.delete("0.0", END)
    ChatLog.insert(END, '\n\n')
    ChatLog.config(state=NORMAL)
    ChatLog.config(foreground="#442265", font=("Verdana", 12))
    ChatLog.insert(END, "You: " + select_id + '\n\n')
    output=getRestAPIOutput(select_id)
    ChatLog.tag_config('bg_yellow', background='yellow')
    ChatLog.insert(END, "Response: \n", 'bg_yellow')
    ChatLog.insert(END, output)
    ChatLog.insert(END, '\n\n')

base = Tk()
base.title("Hello")
base.geometry("500x600")
base.resizable(width=FALSE, height=FALSE)

#Create Chat window
ChatLog = Text(base, bd=0, bg="white", height="8", width="50", font="Arial",)

ChatLog.config(state=DISABLED)

#Bind scrollbar to Chat window
scrollbar = Scrollbar(base, command=ChatLog.yview, cursor="arrow")
ChatLog['yscrollcommand'] = scrollbar.set

#Create Button to send message
SendButton = Button(base, font=("Verdana",12,'bold'), text="Send", width="12", height=5,
                    bd=0, bg="#32de97", activebackground="#3c9d9b",fg='#ffffff',
                    command= send )

#Create the box to enter message
EntryBox = Text(base, bd=0, bg="white",width="29", height="5", font="Arial")
#EntryBox.bind("<Return>", send)


#Place all components on the screen
scrollbar.place(x=480,y=6, height=406)
ChatLog.place(x=6,y=6, height=400, width=470)
EntryBox.place(x=128, y=420, height=90, width=350)
SendButton.place(x=6, y=420, height=90)

base.mainloop()
