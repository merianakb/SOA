import requests

class restAPICall:
    def create_POSTrequest(self,resource_inputs_values,url):
        # Set the request payload (data to be sent with the POST request)
        payload = {}
        for input in resource_inputs_values:
            input_name=input['name']
            input_value=input['value']
            payload[input_name]=input_value
        # Send the POST request
        response = requests.post(url, json=payload)

        # Check the response status code
        if response.status_code == 200:
            # Request was successful
            print('POST request successful')
            print('Response:', response.json())
        else:
            # Request failed
            print('POST request failed')
            print('Response:', response.text)

    def create_GETRequest(self,url):
        file_identifier=input('Please provide  the file identifier: ')
        url=url+'?result-file='+file_identifier
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            print(data)
        else:
            print("Error: ", response.status_code)

