from MethodIdentification import methodsIdentification
from RestAPIIdentification import restapiIdentification
from mainNLU import methods_Identification, getRestAPIOutput
from RestAPICall import restAPICall

prediction_type='remaining time'
pa=''
type=''
methodology=''
algo=[]

predictive_methods=[]
building_methods=[]
submodules=[]

response=methods_Identification.getMethodsThatFeetReq(prediction_type,pa,type,methodology,algo)
if not response[0] == 0:
    predictive_methods = response[2]
    building_methods = response[3]
    submodules = response[4]
print(response[1])

selected_method=input('Select  method ID: ')

output,returned_url,url,resource_inputs_values= getRestAPIOutput(predictive_methods,building_methods,submodules,selected_method)

if(returned_url==1):
    restAPICall.create_POSTRequest(resource_inputs_values,url)