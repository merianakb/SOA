from collections import defaultdict


class MethodClass:
    id=''
    predictionType=''
    pa=''
    type=''
    methodology=''
    algo=[]
    predictorModel=''
    producedModel=''
    task=''
    inputs=[]
    outputs=[]
    submodules=[]
    building_method=[]


    def __init__(self, id, predicitonType,pa, type, methodology, algo, predictorModel, producedModel,task):
        self.id=id
        self.predictionType=predicitonType
        self.pa=pa
        self.type=type
        self.methodology=methodology
        self.algo=algo
        self.predictorModel=predictorModel
        self.producedModel=producedModel
        self.task=task
        self.inputs= []
        self.outputs=[]
        self.submodules=[]
        self.building_method=[]

    def addInput(self, input):
        self.inputs.append(input)
    def addOutput(self, output):
        self.outputs.append(output)
    def addBuildingMethod(self, method_id):
        self.building_method.append(method_id)
    def addSubmodule(self,submodule):
        self.submodules.append(submodule)

    def getMethodID(self):
        return self.id

    def getMethodPredictionType(self):
        return self.predictionType

    def getMethodAwareness(self):
        return self.pa

    def getMethodType(self):
        return self.type

    def getMethodMethodology(self):
        return self.methodology

    def getMethodAlgo(self):
        return self.algo

    def getMethodPredictorModel(self):
        return self.predictorModel

    def getMethodProducedModel(self):
        return self.producedModel
    def getMethodTask(self):
        return self.task

    def getMethodInputs(self):
        return self.inputs

    def getMethodOutputs(self):
        return self.outputs

    def getMethodSubmodules(self):
        return self.submodules
    def getBuildingMethods(self):
        return self.building_method

    def getMethodLiteralInputs(self):
        literal_inputs=[]
        for input in self.inputs:
            if input.type=='literal':
                literal_inputs.append(input)
        return literal_inputs