class InputClass:
    name=''
    format=''
    type=''
    required='no'

    def __init__(self, name, format, type, required):
        self.name=name
        self.format=format
        self.type=type
        self.required=required

    def __init__(self, name, format, type):
        self.name=name
        self.format=format
        self.type=type


    def getInputName(self):
        return self.name

    def getInputFormat(self):
        return self.format

    def getInputType(self):
        return self.type

    def getInputRequired(self):
        return self.required

