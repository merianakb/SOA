from datetime import datetime


class restapiIdentification:
    def identifyRestAPI(self,task,method, literal_inputs_values,resource_inputs_values,is_submodule,submodule_task):
        restapi_url=''
        if task=='':
            end_point='predict'
        else:
            end_point=task
        prediction_type=method.getMethodPredictionType()

        restapi_schema=end_point+'/'+prediction_type.replace(' ','-')+'/'\
                       +method.getMethodMethodology().replace(' ','-')
        algo=str(method.getMethodAlgo()[0])
        restapi_schema=restapi_schema+'/'+algo
        if is_submodule==1:
            restapi_schema = restapi_schema + '/'+submodule_task.replace(' ','-')
        if not len(literal_inputs_values)==0:
            restapi_schema=restapi_schema+'?'
            for input in literal_inputs_values:
                if input['name']=='current time':
                    # datetime object containing current date and time
                    now = datetime.now()
                    # dd/mm/YY H:M:S
                    dt_string = now.strftime("%d-%m-%YT%H:%M:%S")
                    restapi_schema = restapi_schema + input['name'].replace(' ', '-') + '='+dt_string+'&'
                else:
                    restapi_schema=restapi_schema+input['name'].replace(' ','-')+'='+input['value']+'&'
            #remove last &
            restapi_schema=restapi_schema[:-1]
        return restapi_schema